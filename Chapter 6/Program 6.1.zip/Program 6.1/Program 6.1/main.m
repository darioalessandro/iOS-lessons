//
//  main.m
//  Program 6.1
//
//  Created by 23 * Romanovski * 23 on 20/08/12.
//  Copyright (c) 2012 23 * Romanovski * 23. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        int number;
        
        NSLog (@"Escribe un número");
        
        scanf("%i", &number);
        
        if (number < 0) {
            number = -number;
            NSLog(@"El valor absoluto es %i", number );
            
            
        }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    }
    return 0;
}

