//
//  main.m
//  Exercise 6.2
//
//  Created by 23 * Romanovski * 23 on 26/08/12.
//  Copyright (c) 2012 23 * Romanovski * 23. All rights reserved.
/*2. Program 6.8A displays the value in the accumulator even if an invalid operator is entered or division by zero is attempted. Fix that problem.*/

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        
    }
    return 0;
}

