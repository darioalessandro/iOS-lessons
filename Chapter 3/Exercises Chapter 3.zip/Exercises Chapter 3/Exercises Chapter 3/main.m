//
//  main.m
//  Exercises Chapter 3

//2. Based on the example of the car in this chapter, think of an object you use every day. Identify a class for that object and write five actions you do with that object.

/*  
 ClassPersonalCare
 
    [myHair wash]; i am about to wash my hair
    [myHair brush]; i am going to brush it
    [myHair dye]; i´m dyeing my hair
    [myHair therapyMasque]; i am going to do therapy to my hair
    [myHair cut]; i am going to get a haircut*/
    



//  Created by 23 * Romanovski * 23 on 02/08/12.

//  Copyright (c) 2012 23 * Romanovski * 23. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        
    }
    return 0;
}

