//
//  main.m
//  Exercise Chapter 3.2
/*
 [myBoat wash]; i am about to wash my boat
[myCar buyTow]; i am going to buy a tow
[myCar mountTow]; i need to mount the tow
[myMotorcycle inTow]; i am going to mount it on the tow
[myBoat sail]; i am going to go sailing
[myCar trip]; i am going to have a trip
 
 
 4. Imagine that you owned a boat and a motorcycle in addition to a car. List the ac- tions you would perform with each of these. Do you have any overlap between these actions?
 */
//  Created by 23 * Romanovski * 23 on 03/08/12.
//  Copyright (c) 2012 23 * Romanovski * 23. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        
    }
    return 0;
}

