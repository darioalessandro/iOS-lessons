//
//  main.m
//  PRogram 7.2
//
//  Created by 23 * Romanovski * 23 on 29/08/12.
//  Copyright (c) 2012 23 * Romanovski * 23. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Fraction.h"

int main(int argc, const char * argv[])
{
    
          Fraction *aFraction = [[Fraction alloc]init];

    @autoreleasepool {
        
        [aFraction setTo:100 over:200];
        [aFraction print];
        
        
        [aFraction setTo:1 over:3];
        [aFraction print];
        [aFraction release];
        
        
        
                
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    return 0;
}

